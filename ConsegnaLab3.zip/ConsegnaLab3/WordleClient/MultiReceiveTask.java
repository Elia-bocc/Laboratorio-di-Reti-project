package WordleClient;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.util.ArrayList;

public class MultiReceiveTask implements Runnable {
	//struttura dati per memorizzare le partite condivise da tutti gli utente
	ArrayList<String> partite;
	MulticastSocket socket;
	InetAddress group;
	
	public MultiReceiveTask (ArrayList<String> p, MulticastSocket s, InetAddress g) {
		this.partite = p;
		this.socket = s;
		this.group = g;
	}
	
	@SuppressWarnings("deprecation")
	public void run () {
		try {
			byte[] buffer=new byte[1024];
			socket.joinGroup(group);
			while(true){  
		         DatagramPacket packet=new DatagramPacket(buffer, buffer.length);
		         //rimango in attesa del messaggio sul gruppo Multicast
		         socket.receive(packet);
		         String msg=new String(packet.getData(), packet.getOffset(),packet.getLength());
		         //aggiungo la partita condivisa alla struttura dati
		         //la partita condivisa è una stringa json
		         synchronized(partite) {
			         partite.add(msg);
		         }
		      }
		} catch (SocketException e) {
	    	//la socket è stata chiusa sulla receive, è ok
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
