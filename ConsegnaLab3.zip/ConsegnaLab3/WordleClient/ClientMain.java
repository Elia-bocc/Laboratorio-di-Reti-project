package WordleClient;


import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
import java.lang.reflect.Type;
import java.net.*;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;


public class ClientMain {
	
	//creo una classe statica annidata in favore di una maggiore leggibilità del codice,
    //all'interno c'è l'implementazione delle funzioni del client
    public static class Client{
    	//restituisce true se la registrazione va a buon fine
        public static boolean register(String username, String password, DataInputStream in, DataOutputStream out) {
        	try {
        		//invio al server la richiesta di registrazione
        		out.writeUTF("register");
        		out.flush();
            	//creo un oggetto json che rappresenta i dati dell'utente e lo invio al server
            	Gson gson = new Gson();
            	Utente utente = new Utente(username, password);
            	String reg = gson.toJson(utente);
				out.writeUTF(reg);
				out.flush();
				String res = in.readUTF();
				if (res.equals("ok")) {
					System.out.println("Registrazione effettuata con successo");
					return true;
				} else {
					System.out.println("Username già in uso");
					return false;
				}
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
        }
        
        //restituisce true se il login va a buon fine
        public static boolean login(String username, String password, DataInputStream in, DataOutputStream out) {
        	try {
        		//invio al server la richiesta di login
        		out.writeUTF("login");
            	out.flush();
            	//creo un oggetto json che rappresenta i dati dell'utente e lo invio al server
            	Gson gson = new Gson();
            	Utente utente = new Utente(username, password);
            	String log = gson.toJson(utente);
				out.writeUTF(log);
				out.flush();
				String res = in.readUTF();
				if (res.equals("ok")) {
					return true;
				} else if (res.equals("nokk")){
					System.out.println("Hai già effettuato il login");
					return false;
				} else {
                	System.out.println("Username o password errati...");
					return false;
				}
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
        }
        
        //restituisce true se il logout va buon fine
        public static boolean logout (DataInputStream in, DataOutputStream out) {
        	try {
	        	out.writeUTF("logout");
	        	out.flush();
				String res = in.readUTF();
				if (res.equals("ok")) {
					return true;
				} else {
					return false;
				}
        	} catch (IOException e) {
        		e.printStackTrace();
			return false;
        	}
        
        }
        
        //restituisce true se il gioco inizia
        public static boolean playWORDLE (DataInputStream in, DataOutputStream out) {
        	try {
	        	out.writeUTF("playWORDLE");
	        	out.flush();
				String res = in.readUTF();
				if (res.equals("nok")) {
					System.out.println("Questa parola è già stata giocata");
					System.out.println("Attendi la prossima parola");
					return false;
				} else {
					res = in.readUTF();
					System.out.println("SESSIONE DI GIOCO:");
					System.out.println("Codice parola:    "+res);
					System.out.println("");
					return true;
				}
        	} catch (IOException e) {
        		e.printStackTrace();
			return false;
        	}
        
        }
        
        //restituisce true quando il gioco termina, false altrimenti
        public static boolean sendWord (DataInputStream in, DataOutputStream out, Scanner scanner) {
        	try {
        		out.writeUTF("sendWord");
        		out.flush();
	        	System.out.println("Digita la parola");
	        	String parola = scanner.nextLine();
	        	//controllo che la parola sia valida, evitando di mandare al server una parola che so già essere sbagliata
	        	while (parola.length() != 10) {
	        		System.out.println("La parola non ha 10 lettere");
	        		System.out.println("Digita un'altra parola");
	        		parola = scanner.nextLine();
	        	}
        		out.writeUTF(parola);
        		out.flush();
        		parola = in.readUTF();
				if (parola.equals("nok")) {
					//la parola non è presente nel vocabolario
					System.out.println("La parola non è presente nel vocabolario");
					return false;
				} else if (parola.equals("win")) {
					System.out.println("HAI VINTO!!");
					return true;
				} else if (parola.equals("sconfitta")) {
					//terminati i tentativi
					System.out.println("HAI PERSO...");
					parola = in.readUTF();
					System.out.println(parola);
					return true;
				} else {
					//ricevo il numero di tentativi effettuati e stampo quelli mancanti
					String tent = String.valueOf(12-Integer.parseInt(parola));
					System.out.println("Tentativi mancanti: "+tent);
					parola = in.readUTF();
					System.out.println(parola);
					return false;
				}
        	} catch (IOException e) {
        		e.printStackTrace();
        		return false;
        	}
        
        }
        
        //restituisce una stringa che rappresenta le statistiche del giocatore
        public static String sendMeStatistics (DataInputStream in, DataOutputStream out) {
        	try {
	        	out.writeUTF("sendMeStatistics");
	        	out.flush();
				String res = in.readUTF();
				if (res.equals("nok")) {return "Errore statistiche";}
				//se ricevo una statistica la recupero e la restituisco in formato json
		    	Gson gson = new Gson();
				Type uType =new TypeToken<Statistica>() {}.getType();
				//utilizzo il metodo toString() apposta per l'oggetto Statistica
				return gson.fromJson(res, uType).toString();
        	} catch (IOException e) {
        		e.printStackTrace();
        		return "errore";
        	}
        
        }
        
        public static void share (DataInputStream in, DataOutputStream out) {
        	try {
        		out.writeUTF("share");
        		out.flush();
        		String res = in.readUTF();
        		if (res.equals("ok")) {
        			System.out.println("Partita condivisa con successo"); 
        		} else {
        			System.out.println("Si sono verificati dei problemi...");
        		}
        	} catch (IOException e) {
        		e.printStackTrace();
        	}
        
        }
        
        public static void showMeSharing (ArrayList<String> partite) {
        	//mostro sulla console tutte le partite condivise dagli utenti
			System.out.println("PARTITE CONDIVISE: ");
			synchronized(partite){
				for (String e: partite) {
					System.out.println(e);
				}
			}
        }
        
        public static void close (DataInputStream in, DataOutputStream out) {
        	//notifico il server della chiusura
        	try {
				out.writeUTF("close");
				out.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
        }
}
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
    	
    	//leggo il file di configurazione per ottenere le informazioni di inizializzazione del client
        Scanner scan;
        int count = 0;
        //indirizzo socket client/server
        String indirizzo = "";
        //indirizzo gruppo multicast
        String indirizzoMulti = "";
        //porta socket client/server
        int port = 0;
        //indirizzo porta multicast
        int multiPort = 0;
        //timeout server
        int timeout = 0;
		try {		
			scan = new Scanner(new File("configClient.txt"));
	        while(scan.hasNext()) {
	        	scan.next();
	        	if (count==0) {
	        		indirizzo = scan.next();
	        	} else if(count == 1) {
	        		indirizzoMulti = scan.next();
	        	} else if(count == 2) { 
	        		port = scan.nextInt();
	        	} else if (count == 3) {
	        		multiPort = scan.nextInt();
	        	} else {
	        		timeout = scan.nextInt();
	        	}
	        	count += 1;
	        }
	        scan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();     
		}

		//apro la socket, lo scanner datainput/dataoutputstream all'interno del try cosicché vengano chiusi all'uscita del blocco
    	try (Socket s = new Socket(InetAddress.getByName(indirizzo), port);
    			Scanner in = new Scanner(System.in);
    			DataOutputStream out = new DataOutputStream(s.getOutputStream());
            	DataInputStream inp = new DataInputStream(s.getInputStream())){
    			//imposto un timeout di attesa verso il server
    			s.setSoTimeout(timeout);
    			String comando;
    			//Definisco un booleano che vale true se è stato effettuato il login, altrimenti false;
    			//la sua funzione è permettere solo le operazioni di registrazione e login se non si è effettuato il login
    			Boolean login = false;
    			//Definisco un booleano che vale true se è il gioco è in corso, altrimenti false;
    			Boolean gioco = false;
    			//definisco un booleano per poter rendere falso il while principale, in modo da poter far terminare il programma
    			Boolean client = true;
    			//definisco anche una struttura dati contenente le partite ricevute dal gruppo muticast
				ArrayList<String> partite = new ArrayList<String>();
				Thread t = null;
				MulticastSocket socket = null;
				InetAddress group=InetAddress.getByName(indirizzoMulti);
    			while (client) { //ogni volta che faccio il logout torno alla registrazione, potrei voler registrarmi come un altro utente
    				while (!login) {
    					System.out.println("Vuoi registrarti, effettuare il login o chiudere l'applicazione? \n Usa i seguenti comandi:");
    					System.out.println("   - register");
    					System.out.println("   - login");
	    				System.out.println("   - close");
	    				System.out.println("");
    					comando = in.nextLine();
    					//effettuo un primo controllo sulla corretta digitazione del comando letto
    					while (!comando.equals("register") && !comando.equals("login") && !comando.equals("close")) {
    						System.out.println("Comando non trovato...");
    						System.out.println("Digita correttamente il comando");
    						comando = in.nextLine();
    					}
    					switch (comando) {
    					case "register":  //effettuo la registrazione
    						System.out.println("REGISTRAZIONE:");
    	                    while (true) {
    	                        //leggo l'username dell'utente
    	                        System.out.println("Inserisci username: ");
    	                        String username = in.nextLine();
    	                        //leggo la password dell'utente
    	                        System.out.println("Inserisci password: ");
    	                        String password = in.nextLine();
    	                        //se la password è vuota mando un messaggio di errore
    	                        if (password.equals("")) {
    	                            System.out.println("Password vuota");
    	                            System.out.println("Vuoi riprovare? si/no");
    	                            String risposta;
    	                            risposta = in.nextLine();
    	                            while (!risposta.equals("si") && !risposta.equals("no")) {
    	                            	System.out.println("Digita correttamente il comando 'si' oppure 'no'");
    	                            	risposta = in.nextLine();
    	                            }
    	                            // se l'utente non vuole riprovare esco dal while e torno alla fase di registrazione/login
    	                            if (risposta.equals("no")) break; 
    	                            //altrimenti torno direttamente ad inserire l'username e la password
    	                        } else {
    	                            //procedo alla registrazione che è eseguita sul server in mutua esclusione
    	                            //in caso di registrazione avvenuta esco dal while con un break
    	                            if (Client.register(username, password, inp, out)) {
    	                                break;
    	                            } else { //se è già presente chiedo se vuole riprovare
    	                                System.out.println("Vuoi riprovare? si/no");
        	                            String risposta;
        	                            risposta = in.nextLine();
        	                            while (!risposta.equals("si") && !risposta.equals("no")) {
        	                            	System.out.println("Digita correttamente il comando 'si' oppure 'no'");
        	                            	risposta = in.nextLine();
        	                            }
        	                            if (risposta.equals("no")) break; 
    	                            }
    	                        }
    	                    } 
    						break;
    					case "login":  //effettuo il login
    						System.out.println("LOGIN:");
    						while (true) {
	    						//leggo l'username dell'utente
		                        System.out.println("Inserisci username: ");
		                        String username = in.nextLine();
		                        //leggo la password dell'utente
		                        System.out.println("Inserisci password: ");
		                        String password = in.nextLine();
		                        if (Client.login(username, password, inp, out)) { 
		                        	//adesso login diventa true, in modo da simulare l'inizio della sessione e 
		                        	//poter avere accesso a tutte e sole le altre funzioni
		                        	login = true;
		                        	//adesso quindi, lanciando un thread, mi collego al il gruppo multicast,
		                        	//rimango in attesa dei messaggi inviati dai membri del gruppo e li memorizzo;
		                        	socket=new MulticastSocket(multiPort);
		                        	t=new Thread(new MultiReceiveTask(partite, socket, group));
		            			    t.start();
		                        	System.out.println("Login effettuato con successo");
		            				System.out.println("");
		                        	System.out.println("SESSIONE DI LOGIN:");
		            				System.out.println("Digita 'info' in qualsiasi momento per i comandi");
		                        	break;
		                        } else {
		                        	System.out.println("Vuoi riprovare? si/no");
		                            String risposta;
		                            risposta = in.nextLine();
		                            while (!risposta.equals("si") && !risposta.equals("no")) {
		                            	System.out.println("Digita correttamente il comando 'si' oppure 'no'");
		                            	risposta = in.nextLine();
		                            }
		                            if (risposta.equals("no")) break; 
		                        }
    						}
    						break;
    					case "close":
    						Client.close(inp, out);
    						login = true;
    						client = false;
    						break;
    					}
    				}
    				
    				
    				if (client) {
	    				System.out.println("Digita un comando:");
	    				System.out.println("");
	
	    				
	    				comando = in.nextLine();
	    				switch (comando) {
	    				case "logout":
							login = false;
							gioco = false;
							//comunicare con il server
							if (Client.logout(inp, out)) {
								//resetto la struttura dati contenente le partite condivise dagli utenti sul gruppo
								partite.clear();
							    socket.leaveGroup(group);
							    socket.close();
								t.interrupt();
								System.out.println("");
						    	System.out.println("SESSIONE DI LOGIN TERMINATA");
							} else {
								System.out.println("Il server ha problemi...");
							}
							break;
	    				case "playWORDLE":
							//controllo che non sia già stata avviata un'altra sessione di gioco
							if (gioco == false) {			
								//preparazione ed avvio del gioco
								if (Client.playWORDLE(inp, out)) {
									gioco = true;
								}
							} else {
								//se la sessione di gioco è già attiva
								System.out.println("Stai già giocando");
							}
							break;
	    				case "sendMeStatistics":
							String stat = Client.sendMeStatistics(inp, out);		
							System.out.println(stat);
							break;
	    				case "sendWord":
							if (gioco == true) {
								//se viene restituito true vuol dire che il gioco è terminato
								//perciò chiedo se vuole condividere il risultato
								//è possibile condividere il risultato solo alla fine del gioco
								if (Client.sendWord(inp, out, in)) {
									gioco = false;
									System.out.println("");
									System.out.println("SESSIONE DI GIOCO TERMINATA");
									System.out.println("Vuoi condividere la tua partita? si/no");
									comando = in.nextLine();
									while (!comando.equals("si") && !comando.equals("no")) {
		                            	System.out.println("Digita correttamente il comando 'si' oppure 'no'");
		                            	comando = in.nextLine();
		                            }
									if (comando.equals("si")) {
										Client.share(inp, out);
									} else {
										out.writeUTF("nok");
									}
								}
							} else {
								System.out.println("Inizia a giocare prima di provare ad indovinare");
							}
							break;
	    				case "showMeSharing":
							Client.showMeSharing(partite);
							break;
	    				case "info":
							System.out.println("Comandi:");
		    				System.out.println("- logout");
		    				System.out.println("- playWORDLE");
		    				System.out.println("- sendMeStatistics");
		    				System.out.println("- sendWord");
		    				System.out.println("- showMeSharing");
		    				break;
		    			default:
		    				System.out.println("Comando non trovato...");
						}
    				}
    			}
				System.out.println("Applicazione chiusa");    			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException ex) {
			//il server ha raggiunto capienza massima oppure non è attivo
			System.out.println("Il server ha raggiunto capienza massima oppure non è attivo");
		}
    }
}