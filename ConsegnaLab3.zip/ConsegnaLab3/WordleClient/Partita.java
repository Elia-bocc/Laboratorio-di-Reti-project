package WordleClient;
import java.util.ArrayList;

public class Partita {
	
	private String word;
	private int tentativi = 0;
	private ArrayList<String> indizi = new ArrayList<String>();
	private String esito = "abbandono";
	
	
	public String getW() {return word;}
	
	public void setW(String s) {word = new String(s);}
	
	public int getT() {return tentativi;}
	
	public void addT() {tentativi += 1;}
	
	public void resT() {tentativi = 0;}
	
	public ArrayList<String> getI() {return indizi;}
	
	public void addI(String indizio) {indizi.add(indizio);}
	
	public void resI() {indizi = new ArrayList<String>();}
	
	public String getE() {return esito;}
	
	public void setWin() {esito = "vittoria";}
	
	public void setDefeat () {esito = "sconfitta";}
	
	public void resE () {esito = "abbandono";}
	
}