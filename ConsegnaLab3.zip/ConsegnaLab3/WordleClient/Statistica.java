package WordleClient;
import java.util.ArrayList;

public class Statistica {
	
	private int n_partite = 0;
	private double percent_win = 0;
	private int current_streak = 0;
	private int max_streak = 0;
	private ArrayList<Double> distribuzione_tentativi = new ArrayList<Double>();
	
	public Statistica () {
		for (int i=0; i<12; i++) {
			distribuzione_tentativi.add((double)0);
		}
	}
	
	public int getNum_p() {return n_partite;}
	
	public double getPercent() {return percent_win;}
		
	public int getCurrStreak() {return current_streak;}
	
	public int getMaxStreak() {return max_streak;}
	
	public void setMax(int m) {max_streak = m;}
	
	public ArrayList<Double> getDistr() {return distribuzione_tentativi;}
	
	//metodo che aggiorna le statistiche
	public void updateStat(Partita p) {
		double vinte = n_partite * percent_win / 100;
		n_partite+=1;
		if (p.getE().equals("vittoria")) {
			percent_win = (vinte + 1) / n_partite * 100;
			current_streak+=1;
			if (current_streak > max_streak) {max_streak = current_streak;}
			for (int i = 0; i<distribuzione_tentativi.size(); i++) {
				if (i == p.getT()-1) {
					distribuzione_tentativi.set(i, ((distribuzione_tentativi.get(i)*vinte)+1)/(vinte+1));
				} else {
					distribuzione_tentativi.set(i, distribuzione_tentativi.get(i)*vinte/(vinte+1));
				}
			}
		} else {
			percent_win = vinte / n_partite * 100;
			current_streak = 0;
		}
		
		
		
	}
	
	public String toString() { 
	    return String.format("%s%n%s%n%s%n%s%n%s", "Partite giocate: "+n_partite, "Percentuale vittorie: "+percent_win,
	    										"Hai una striscia vincente di "+current_streak+" partite",
	    										"Massima striscia vincente: "+max_streak+" partite",
	    										"Distribuzione dei tentativi sulle vittorie: "+distribuzione_tentativi.toString());
	} 
}

