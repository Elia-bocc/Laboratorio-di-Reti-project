package WordleServer;

public class Guardia {
	
	volatile private boolean b = true;
	
	public boolean getB() {return b;}
	
	public void setT() { b = true;}
	
	public void setF() {b = false;}
	
}
