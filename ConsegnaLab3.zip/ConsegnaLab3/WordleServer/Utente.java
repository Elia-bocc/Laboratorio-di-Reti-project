package WordleServer;

public class Utente {
	private String username;
	private String password;
	public Utente (String username, String password) {
		this.username = username;
		this.password = password;
	}
	public String getU() {return username;}
	
	public String getP() {return password;}
}

