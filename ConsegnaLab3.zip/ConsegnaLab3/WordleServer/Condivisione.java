package WordleServer;
import java.util.ArrayList;

public class Condivisione {
	
	private String username;
	private String parola;
	private int tentativi_effettuati;
	private ArrayList<String> indizi;
	
	public Condivisione (String u, String p, int t, ArrayList<String> i) {
		this.username = u;
		this.parola = p;
		this.tentativi_effettuati = t;
		this.indizi = i;
	}
	
	public String getU () {return username;}
	
	public String getP () {return parola;}
	
	public int getT () {return tentativi_effettuati;}
	
	public ArrayList<String> getI () {return indizi;}
}
