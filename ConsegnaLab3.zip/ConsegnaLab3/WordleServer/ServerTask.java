package WordleServer;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;
import java.io.*;
import com.google.gson.*;
import java.lang.reflect.*;
import com.google.gson.reflect.*;


public class ServerTask implements Runnable {
	Socket socket;
    ConcurrentHashMap<String, String> utenti;
    ConcurrentHashMap<String, Statistica> statistiche;
    ConcurrentHashMap<String, ArrayList<String>> parole;
    AtomicReference<String> sw;
    ArrayList<String> words;
    List<String> logs;
    MulticastSocket multiSocket;
    InetAddress group;
    int multiPort;
    public ServerTask (Socket socket, ConcurrentHashMap<String, String> utenti, ConcurrentHashMap<String,
    					Statistica> statistiche, ConcurrentHashMap<String, ArrayList<String>> parole, 
    					AtomicReference<String> sw, ArrayList<String> words, List<String> logs,
    					MulticastSocket multiSocket, InetAddress group, int multiPort){
        this.socket = socket;
        this.utenti = utenti;
        this.statistiche = statistiche;
        this.parole = parole;
        this.sw = sw;
        this.words = words;
        this.logs = logs;
        this.multiSocket = multiSocket;
        this.group = group;
        this.multiPort = multiPort;
    }
    
    //metodo per la condivisione della partita
    //creato per evitare la duplicazione del codice
    public void share(Gson gson, Utente utente, Partita partita, DataOutputStream out, String codiceParola) throws IOException {
    	//condivido la partita sul gruppo multicast creando un oggetto condivisione con i dati della partita
	      String messaggio = gson.toJson(new Condivisione(utente.getU(), codiceParola, partita.getT(), partita.getI()));
	      byte[] msg = messaggio.getBytes();
	      DatagramPacket packet = new DatagramPacket(msg, msg.length, group, multiPort);
	      synchronized (multiSocket) {
		      multiSocket.send(packet); 
	      }
	      out.writeUTF("ok");
	      out.flush();
    }

    public void run () {
    	
    	//definisco delle variabili che serviranno in tutto il codice
    	Boolean login = false;
    	Boolean gioco = false;
    	Boolean client = true;
    	Statistica stat;
    	Partita partita = new Partita();
    	String codiceParola = "";
    	//definisco gli strumenti per deserializzare/serializzare gli oggetti json che ricevo
    	//questo particolare oggetto json è in grado di serializzare in modo molto leggibile
    	//scelto in particolare per mostrare le statistiche e condividere la partita
    	Gson gson = new GsonBuilder().setPrettyPrinting().create();;
    	Type uType = new TypeToken<Utente>() {}.getType();
    	//creo gli stream di I/O
    	//li creo all'interno delle parentesi tonde in modo che al termine del blocco vengano chiusi automaticamente
    		try (DataInputStream in= new DataInputStream(socket.getInputStream());
    			DataOutputStream out = new DataOutputStream(socket.getOutputStream())){
				String ricezione;
				Utente utente;
				while (client) {
					//rimango in attesa di una richiesta finchè il client non chiude la connessione
					ricezione = in.readUTF();
					switch (ricezione) {
					  case "register":
						  //registrazione
						  //leggo i dati di registrazione
						  ricezione = in.readUTF();
						  //spacchetto l'oggetto .json					  
						  utente=gson.fromJson(ricezione, uType);
						  //controllo sulla struttura dati condivisa che lo username non sia già in uso utilizzando la funzione composta putIfAbsent,
						  //che in caso positivo salva i dati, successivamente aggiorno il file utenti.json in modo sincronizzata
						  if ( utenti.putIfAbsent(utente.getU(), utente.getP()) != null) {
							  //notifico il client che questo username è già in uso
							  out.writeUTF("nok");
							  out.flush();
						  } else {
							  //aggiorno il file utenti.json
							  Synchro.updateJsonU(utente);
							  //inserisco nelle statistiche l'inizializzazione della statistica dell'utente e aggiorno statistiche.json
							  stat = new Statistica(); 
							  statistiche.put(utente.getU(), stat);
							  Synchro.updateJsonS(new U_Stat(utente.getU(), stat));
							  //notifico il client dell'avvenuta registrazione
							  //il messaggio di successo viene mandato dopo aver salvato i dati sul file persistente per garantire la consistenza
							  out.writeUTF("ok");
							  out.flush();
						  }
					    break;
					  case "login":
						  //login
						  //leggo i dati di login
						  ricezione = in.readUTF();
						  //spacchetto l'oggetto .json						  
						  utente=gson.fromJson(ricezione, uType);
						  //controllo che l'utente sia registrato
						  //in caso positivo restituisco "ok", in caso negativo "nok", altrimenti se è già loggato "nokk"
						  if (utenti.containsKey(utente.getU()) && utenti.get(utente.getU()).equals(utente.getP())) {
							  //controllo che l'utente non abbia già effettuato il login
							  if (logs.contains(utente.getU())) {
								  out.writeUTF("nokk");
								  out.flush();
							  } else {
								  //aggiungo l'utente dagli utenti collegati in questo momento
								  logs.add(utente.getU());
								  login = true;
								  out.writeUTF("ok");
								  out.flush();
								  while (login) {
									  //adesso l'utente è in sessione di login, quindi metto a disposizione le altre funzioni e attendo un nuovo comando
									  ricezione = in.readUTF();
									  switch (ricezione) {
									  case "logout":
										  //logout
										  //rimuovo l'utente dagli utenti collegati in questo momento e modifico le guardie
										  logs.remove(utente.getU());
										  login = false;
										  gioco = false;
										  out.writeUTF("ok");
										  out.flush();
											break;
									  case "playWORDLE":
										  if (gioco == false) {
											  //leggo la parola, aggiorno la struttura dati delle parole, il codice della parola, dico al client che il gioco è iniziato e rimango in attesa di parole
											  String word = new String(sw.get());
											  codiceParola = String.valueOf(words.indexOf(word));
											  //prendo la lista di parole giocate dall'utente
											  ArrayList<String> wordss = parole.get(utente.getU());
											  //se viene restituito null vuol dire che è la prima sessione di gioco dell'utente
											  //quindi creo l'arraylist, aggiungo la parola, aggiungo la mappa alla concurrentHashMap e aggiorno il file parole.json
											  if (wordss == null) {
												  ArrayList<String> nuoveParole = new ArrayList<String>();
												  nuoveParole.add(word);
												  parole.put(utente.getU(), nuoveParole);
												  Synchro.updateJsonP(new Parole(utente.getU(),nuoveParole));
												  //viene inizializzata la partita impostando la parola e resettando la partita precedente
												  partita.setW(word);
												  partita.resI();
												  partita.resT();
												  partita.resE();
												  //imposto la guardia che rappresenta la sessione di gioco e notifico il client
												  gioco = true;
												  out.writeUTF("ok");
												  out.flush();
												  //invio il codice della parola
												  out.writeUTF(codiceParola);
												  out.flush();
												  //inizia il gioco
											  } else {
												//altrimenti controllo che non sia già stata giocata dall'utente
												  if (!wordss.contains(word)) {
													  //aggiorno la struttura dati che memorizza le parole giocate da ciascun giocatore e anche il file parole.json
													  wordss.add(word);
													  Synchro.updateJsonP(new Parole(utente.getU(), wordss));
													  //viene inizializzata la partita impostando la parola e resettando la partita precedente
													  partita.setW(word);
													  partita.resI();
													  partita.resT();
													  partita.resE();
													  //imposto la guardia che rappresenta la sessione di gioco e notifico il client
													  gioco = true;
													  out.writeUTF("ok");
													  out.flush();
													  //invio il codice della parola
													  out.writeUTF(codiceParola);
													  out.flush();
													  //inizia il gioco
												  } else {
													  //la parola è già stata giocata dall'utente
													  out.writeUTF("nok");
													  out.flush();
												  }
											  }
										  }
										  
											break;
									  case "sendMeStatistics":
										  //recupero le statistiche dell'utente dalla concurrentHashMap e le invio al client in formato json
										  stat = statistiche.get(utente.getU());
										  if (stat != null) {
											  out.writeUTF(gson.toJson(stat));
											  out.flush();
										  } else {
											  out.writeUTF("nok");
											  out.flush();
										  }
											break;
									  case "sendWord":
										  if (gioco == true) {
											  //ricevo la guess word
											  ricezione = in.readUTF();
											  //controllo prima se la parola è stata indovinata
											  if (ricezione.equals(partita.getW())) {
												  //incremento i tentativi della partita
												  partita.addT();
												  //salvo la vittoria e la aggiungo alla lista dei tentativi della partita
												  partita.setWin();
												  partita.addI("++++++++++");
												  //calcolo le statistiche e aggiorno il file statistiche.json
												  stat = statistiche.get(utente.getU());
												  stat.updateStat(partita);
												  Synchro.updateJsonS(new U_Stat(utente.getU(), stat));
												  //aggiorno anche la struttura dati
												  statistiche.replace(utente.getU(), stat);
												  //notifico la vittoria
												  out.writeUTF("win");
												  out.flush();
												  //modifico la variabile che rappressenta la sessione di gioco
												  gioco = false;
												  //siccome la partita è terminata rimango in attesa della risposta del client sul voler condividere la partita oppure no
												  ricezione = in.readUTF();
												  if (ricezione.equals("share")) {this.share(gson, utente, partita, out, codiceParola);}
											  } else {
												  //la parola non è stata indovinata
												  //processo la parola inviata dal client
												  //controllo che sia presente all'interno del vocabolario
												  if(!words.contains(ricezione)) {
													  out.writeUTF("nok");
													  out.flush();
												  } else {
													  //incremento i tentativi della partita
													  partita.addT();
													  //elaboro l'indizio
													  //inizializzo l'indizio con tutte x, come se la parola fosse interamente sbagliata
													  String indizio = "xxxxxxxxxx";
													  String word = partita.getW();
													  for (int i=0; i<word.length(); i++) {
														  if (ricezione.charAt(i) == word.charAt(i)) {
															  //ho indovinato la lettera nella posizione giusta quindi inserisco "+" nella posizione dell'indizio
															  indizio = indizio.substring(0, i)+"+"+indizio.substring(i+1);
														  } else {
															  //altrimenti controllo se è presente nella parola, in caso positivo inserisco "?" nella posizione dell'indizio
															  if (Pattern.compile(Character.toString(ricezione.charAt(i))).matcher(word).find()) {
																  indizio = indizio.substring(0, i)+"?"+indizio.substring(i+1);
															  }
														  }
													  }
													  
													 if (partita.getT() < 12) {
														  //non ho ancora raggiunto il numero massimo di tentativi, quindi li invio
														  out.writeUTF(String.valueOf(partita.getT()));
														  out.flush();
														  //aggiorno la partita con l'indizio e lo invio
														  partita.addI(indizio);
														  out.writeUTF(indizio);
														  out.flush();
													  } else {
														  //aggiorno la partita con la sconfitta
														  partita.setDefeat();
														  //modifico la variabile che rappresenta la sessione di gioco
														  gioco = false;
														  //calcolo le statistiche e aggiorno il file statistiche.json
														  stat = statistiche.get(utente.getU());
														  stat.updateStat(partita);
														  //aggiorno anche la struttura dati
														  statistiche.replace(utente.getU(), stat);
														  Synchro.updateJsonS(new U_Stat(utente.getU(), stat));
														  //notifico al client che ha terminato i tentativi e quindi della sconfitta
														  out.writeUTF("sconfitta");
														  out.flush();
														  //aggiorno la partita con l'indizio e lo invio
														  partita.addI(indizio);
														  out.writeUTF(indizio);
														  out.flush();
														  //siccome la partita è terminata rimango in attesa della risposta del client sul voler condividere la partita oppure no
														  ricezione = in.readUTF();
														  if (ricezione.equals("share")) {this.share(gson, utente, partita, out, codiceParola);}
														  
													  }
												  }
											  }
										  }
											break;
									  default:
									    // code block;
									  }
								  }
						  	  }
						  } else {
							  out.writeUTF("nok");
							  out.flush();
						  }
					    break;
					  case "close":
						  client = false;
						  break;
					  default:
					    // code block
					}
				}
			} catch (IOException e) {
				//System.out.println("Disconnessione improvvisa del client");
			}    	
    }
}
