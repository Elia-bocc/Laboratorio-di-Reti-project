package WordleServer;
import java.util.ArrayList;

public class Parole {
	
	private String username;
	private ArrayList<String> parole;
	
	public Parole (String username, ArrayList<String> parole) {
		this.username = username;
		this.parole = parole;
	}
	
	public String getU() {return username;}
	
	public ArrayList<String> getP() {return parole;}
}
