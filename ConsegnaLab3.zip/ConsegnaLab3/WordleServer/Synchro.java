package WordleServer;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.*;

public class Synchro {
	synchronized public static void updateJsonU(Utente u) {
		//creo una lista, inserisco l'utente da aggiungere, estraggo i vecchi utenti ed infine li scrivo tutti sul file
		List<Utente> lista = new ArrayList<Utente>();
		lista.add(u);
		Type uType = new TypeToken<Utente>() {}.getType();
		Gson gson = new Gson();
		try (JsonReader reader = new JsonReader(new FileReader("utenti.json"));) {//se il file è vuoto viene sollevata un eccezione e passa avanti   	
	        reader.beginArray();
	        while ( reader.hasNext()) {
	            lista.add(gson.fromJson(reader, uType));
	        }
	        reader.endArray();
		 } catch (FileNotFoundException e) {
         	System.err.println(e.getMessage());
         } catch (IOException e) {
        	 //System.err.println(e.getMessage());
         }
         	
         	//scrivo tutti gli utenti sul file
			try (JsonWriter writer = new JsonWriter(new FileWriter("utenti.json"))) {
				writer.beginArray();
	         	for (Utente utente : lista) {
	         	      writer.beginObject();
	         	      writer.name("username").value(utente.getU());
	         	      writer.name("password").value(utente.getP());
	         	      writer.endObject();
	         	}
	         	writer.endArray();
			} catch (IOException e) {
				e.printStackTrace();
			}		
	}
	
	synchronized public static void updateJsonS(U_Stat s) {
		//creo una lista, inserisco la statistica da aggiungere, estraggo le vecchie statistiche
		//controllando di non estrarre quella che sto aggiornando ed infine le scrivo tutte sul file
		List<U_Stat> lista = new ArrayList<U_Stat>();
		lista.add(s);
		U_Stat u_stat;
		Type uType = new TypeToken<U_Stat>() {}.getType();
		Gson gson = new Gson();
		try (JsonReader reader = new JsonReader(new FileReader("statistiche.json"));) {//se il file è vuoto viene sollevata un eccezione e va avanti   	
	        reader.beginArray();
	        while ( reader.hasNext()) {
	         	u_stat = gson.fromJson(reader, uType);
	         	if (!s.getU().equals(u_stat.getU())) {
	         		lista.add(u_stat);	
	         	}
	        }
	        reader.endArray();
		 } catch (FileNotFoundException e) {
         	System.err.println(e.getMessage());
         } catch (IOException e) {
        	 //System.err.println(e.getMessage());
         }
         	
         	//scrivo tutte le statistiche sul file
			try (JsonWriter writer = new JsonWriter(new FileWriter("statistiche.json"))) {
				writer.beginArray();
	         	for (U_Stat statistica : lista) {
	         	      writer.beginObject();
	         	      writer.name("username").value(statistica.getU());
	         	      writer.name("statistica");
	         	      writer.beginObject();
	         	      writer.name("n_partite").value(statistica.getS().getNum_p());
	         	      writer.name("percent_win").value(statistica.getS().getPercent());
	         	      writer.name("current_streak").value(statistica.getS().getCurrStreak());
	         	      writer.name("max_streak").value(statistica.getS().getMaxStreak());
	         	      writer.name("distribuzione_tentativi");
	         	      writer.beginArray();
	         	      for (double el: statistica.getS().getDistr()) {
	         	    	  writer.value(el);
	         	      }
	         	      writer.endArray();
	         	      writer.endObject();
	         	      writer.endObject();
	         	}
	         	writer.endArray();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
	
	synchronized public static void updateJsonP(Parole p) {
		//creo una lista, inserisco le parole da aggiungere, estraggo le vecchie parole
		//controllando di non estrarre quelle che sto aggiornando ed infine le scrivo tutte sul file
		List<Parole> lista = new ArrayList<Parole>();
		lista.add(p);
		Parole par;
		Type uType = new TypeToken<Parole>() {}.getType();
		Gson gson = new Gson();
		try (JsonReader reader = new JsonReader(new FileReader("parole.json"));) {//se il file è vuoto viene sollevata un eccezione e passa avanti   	
	        reader.beginArray();
	        while ( reader.hasNext()) {
	         	par = gson.fromJson(reader, uType);
	            if (!p.getU().equals(par.getU()))
	         		lista.add(par);
	        }
	        reader.endArray();
		 } catch (FileNotFoundException e) {
         	System.err.println(e.getMessage());
         } catch (IOException e) {
        	 //System.err.println(e.getMessage());
         }
         	
         	//scrivo tutte le parole sul file
			try (JsonWriter writer = new JsonWriter(new FileWriter("parole.json"))) {
				writer.beginArray();
	         	for (Parole parole : lista) {
	         	      writer.beginObject();
	         	      writer.name("username").value(parole.getU());
	         	      writer.name("parole");
	         	      writer.beginArray();
	         	      for (String el: parole.getP()) {
	         	    	  writer.value(el);
	         	      }
	         	      writer.endArray();
	         	      writer.endObject();
	         	}
	         	writer.endArray();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}

}