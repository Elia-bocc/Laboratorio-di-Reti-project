package WordleServer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;


public class ServerMain {


	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
    	//leggo il file di configurazione per ottenere le informazioni di inizializzazione del server
		Scanner scan;
        int count = 0;
        //indirizzo multicast
        String indirizzoMulti = "";
        //porta socket client/server
        int port = 0;
        //porta multicast
        int multiPort = 0;
        //periodo parola
        int periodo = 0;
        //tempo attesa terminazione tasks
        long time = 0;
        //corePoolSize
        int core = 0;
        
		try {		
			scan = new Scanner(new File("configServer.txt"));
			while(scan.hasNext()) {
	        	scan.next();
	        	if (count==0) {
	        		indirizzoMulti = scan.next();
	        	} else if(count == 1) {
	        		port = scan.nextInt();
	        	} else if(count == 2) { 
	        		multiPort = scan.nextInt();
	        	} else if (count == 3) {
	        		periodo = scan.nextInt();
	        	} else if (count == 4){
	        		time = scan.nextLong();
	        	} else {
	        		core = scan.nextInt();
	        	}
	        	count += 1;
	        }
	        scan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();     
		}

		
		//creo le socket all'interno del try cosicchè si chiuda all'uscita del blocco
		try (ServerSocket server = new ServerSocket(port);
			MulticastSocket multiSocket = new MulticastSocket(multiPort);) { 
			
			//unisco la multicast socket al gruppo multicast
			InetAddress group = InetAddress.getByName(indirizzoMulti);
	        multiSocket.joinGroup(group);
			
            // creo la struttura dati che memorizza gli utenti registrati rappresentati come coppia (username/password)
	        //ho scelto una concurenthashmap perchè era necessaria una struttura dati thread safe e con operazioni atomiche composte,
	        //che fosse anche efficiente. Inoltre è molto comoda la rappresentazione chiave-valore
            ConcurrentHashMap<String, String> utenti = new ConcurrentHashMap<String, String>(); 
            // questa struttura dati che ho appena creato la inizializzo con il file json che ho creato se non è vuoto, e poi lo passo a ciascun thread
            //per leggerlo lo deserializzo utilizzando il tipo Utente, in modo molto semplice
            
            //creo il file se non esiste già
            File f = new File("utenti.json");
            if (!f.createNewFile()) {
	            try (JsonReader reader = new JsonReader(new FileReader(f))){	 
	            	 Gson gson = new Gson();
	            	 Type uType = new TypeToken<Utente>() {}.getType();
	            	 Utente utente;
	            	 reader.beginArray();
	            	 while (reader.hasNext()) {
	                     utente = gson.fromJson(reader, uType);
	                     utenti.put(utente.getU(), utente.getP());
	                  }
	            	 reader.endArray();
	            } catch (FileNotFoundException e) {
	            	System.err.println(e.getMessage());
	            } catch (IOException e) {
                	//System.err.println(e.getMessage());
	            }
            }
            
            // creo la struttura dati che memorizza tutti le statistiche degli utenti rappresentate come coppia
            // (username/{"n_partite": 6, "percent_win": 30, "current_streak": 1, "max_streak": 3, "distribuzione_tentativi": [0,0,0,1,0,2,1,2,4,3,5,7]})
            ConcurrentHashMap<String, Statistica> statistiche = new ConcurrentHashMap<String, Statistica>();
            //anche questa struttura dati che ho appena creato la inizializzo con il file json che ho creato se non è vuoto, e poi lo passo a ciascun thread
            
          //creo il file se non esiste già
            f = new File("statistiche.json");
            if (!f.createNewFile()) {
	            try (JsonReader reader = new JsonReader(new FileReader(f))){	 
	           	 Gson gson = new Gson();
	           	 Type uType = new TypeToken<U_Stat>() {}.getType();
	           	 U_Stat utente;
	           	 reader.beginArray();
	           	 while (reader.hasNext()) {
	                    utente = gson.fromJson(reader, uType);
	                    statistiche.put(utente.getU(), utente.getS());
	                 }
	           	 reader.endArray();
	            } catch (FileNotFoundException e) {
	            	System.err.println(e.getMessage());
	            } catch (IOException e) {
	            	//System.err.println(e.getMessage());
	            }
            }
            
            
            // creo la struttura dati che memorizza tutte le parole giocate dagli utenti rappresentate come coppia
            // (username/[parola1, parola2, ec...])
            ConcurrentHashMap<String, ArrayList<String>> parole = new ConcurrentHashMap<String, ArrayList<String>>();
            //anche questa struttura dati che ho appena creato la inizializzo con il file json che ho creato se non è vuoto, e poi lo passo a ciascun thread
            
            //creo il file se non esiste già
            f = new File("parole.json");
            if (!f.createNewFile()) {
	            try (JsonReader reader = new JsonReader(new FileReader(f))){	 
	           	 Gson gson = new Gson();
	           	 Type uType = new TypeToken<Parole>() {}.getType();
	           	 Parole utente;
	           	 reader.beginArray();
	           	 while (reader.hasNext()) {
	                    utente = gson.fromJson(reader, uType);
	                    parole.put(utente.getU(), utente.getP());
	                 }
	           	 reader.endArray();
	            } catch (FileNotFoundException e) {
	            	System.err.println(e.getMessage());
	            } catch (IOException e) {
	            	//System.err.println(e.getMessage());
	            }
            }
                
            
            //definisco una struttura dati per memorizzare le secret words che poi sarà condivisa, 
            //in modo da evitare di aprire e leggere il file words.txt ogni volta
            ArrayList<String> words = new ArrayList<String>();
            
            //utilizzo BufferedReader per rendere la lettura più efficiente
            BufferedReader in = new BufferedReader(new FileReader("words.txt"));
            String word;
            while((word = in.readLine()) != null) {
            	words.add(word);
            }
            in.close();
            
            //definisco una struttura dati sincronizzata per memorizzare gli utenti che sono momentaneamente loggati
            List<String> logs = Collections.synchronizedList(new ArrayList<String>());
            
            //definisco una variabile String atomica che sarà utilizzata come parola segreta condivisa tra tutti i threads
            AtomicReference<String> sw = new AtomicReference<String>(); 
            
            //creo una threadpool con un singolo thread che esegue un task periodicamente, 
            //in questo caso il task modifica la secret word ogni volta che viene eseguito,
            //il periodo viene preso come parametro di configurazione     
            ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
            executorService.scheduleAtFixedRate(new UpdateWordTask(sw, words), 0, periodo, TimeUnit.SECONDS);
            
            
            //scelgo di usare una custom threadPool perchè essendo in un gioco social non ho idea di quante connessioni ci saranno,
         	//tenendo anche conto di periodo di punta e periodi con afflussi minimi (pomeriggio e notte), 
         	//comunque però fisso un numero massimo di threads gestibile
         	//utilizzo una SynchronousQueue in modo da servire subito la richiesta se non si è raggiunto il numero massimo di threads, 
         	//altrimenti sarà momentaneamente impossibile collegarsi
         	SynchronousQueue<Runnable> queue = new SynchronousQueue<Runnable>();
            ExecutorService service = new ThreadPoolExecutor(0, core, 60L,TimeUnit.SECONDS, queue);
                        
            //avvio un thread per poter terminare correttamente il server
            //inizializzo la guardia con un oggetto di tipo Guardia, per indicare fino a quando l'executor continuerà ad operare
            //il tipo guardia ha all'interno un booleano volatile, in modo che appena cambia valore nel task di terminazione 
            //venga aggiornata anche la memoria principale, altrimenti la terminazione non sarebbe proseguita
            Guardia serv = new Guardia();
            Thread t=new Thread(new TerminazioneTask(service, serv, port));
		    t.start();
		    
            System.out.println("Server attivo");
            while (serv.getB()) {
            	try {
            		service.execute(new ServerTask(server.accept(), utenti, statistiche, parole, 
            										sw, words, logs, multiSocket, group, multiPort));
            	} catch (RejectedExecutionException e) {
            		//gestisco il caso in cui i threads sono tutti occupati oppure l'executor ha avviato la terminazione e qualcuno tenta di collegarsi
            		//non fare niente
            	}
            }
            //termino la scheduledAtFixedRate
            executorService.shutdownNow();
            //attendo che gli utenti terminino la loro partita
            //se però passa più di time secondi smetto di aspettare e interrompo il server 
			service.awaitTermination(time, TimeUnit.SECONDS);
			//lascio il gruppo multicast
            multiSocket.leaveGroup(group);
            System.out.println("Server terminato correttamente");
        } catch (IOException ex) {
            System.err.println(ex);
        } catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}