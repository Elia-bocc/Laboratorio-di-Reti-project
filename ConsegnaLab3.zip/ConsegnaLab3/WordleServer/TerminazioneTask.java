package WordleServer;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;

public class TerminazioneTask implements Runnable{
	ExecutorService service;
	Guardia serv;
	int port;
	
	public TerminazioneTask (ExecutorService s, Guardia b, int p) {
		this.service = s;
		this.serv = b;
		this.port = p;
	}
	
	public void run() {
		//rimane in attesa del comando di terminazione da linea di comando
		//una volta arrivato avvia lo sutdown dell'executor
		Boolean wait = true;
		String ric;
		try (Scanner scan = new Scanner(System.in)) {
			while (wait) {
				//in attesa della parola di terminazione
				ric = scan.nextLine();
				//se il comando ricevuto è "shutdown" procedo modificando le guardie
				//e inizio a terminare l'executor
				if (ric.equals("shutdown")) {
					wait = false;
					serv.setF();
					service.shutdown();
					System.out.println("Chiusura in corso....");
					//sblocco l'executor sul thread principale
					try (Socket s = new Socket(InetAddress.getLocalHost(), port)) {
						
					} catch (UnknownHostException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
    }
}
