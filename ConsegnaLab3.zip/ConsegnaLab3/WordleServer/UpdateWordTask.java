package WordleServer;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicReference;

public class UpdateWordTask implements Runnable {
	AtomicReference<String> sw;
	List<String> words;
	
	public UpdateWordTask (AtomicReference<String> sw, List<String> words) {
		this.sw = sw;
		this.words = words;
	}
	
	public void run() {
		//aggiorno la parola atomicamente
    	sw.set(words.get(new Random().nextInt(words.size()-1)));
    }
}
