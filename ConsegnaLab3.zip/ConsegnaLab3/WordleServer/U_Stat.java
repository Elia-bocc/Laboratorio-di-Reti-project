package WordleServer;
public class U_Stat {
	
	private String username;
	private Statistica statistica;
	
	public U_Stat (String username, Statistica statistica) {
		this.username = username;
		this.statistica = statistica;
	}
	
	public String getU() {return username;}
	
	public Statistica getS() {return statistica;}
}
